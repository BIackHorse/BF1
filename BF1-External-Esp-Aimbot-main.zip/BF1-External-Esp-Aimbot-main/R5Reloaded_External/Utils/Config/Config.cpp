#include "Config.h"

cfg g;